﻿
$(document).ready(function () {

    $(".sidebar-dropdown > a").click(function () {
        $(".sidebar-submenu").slideUp(200);
        if (
            $(this)
                .parent()
                .hasClass("active")
        ) {
            $(".sidebar-dropdown").removeClass("active");
            $(this)
                .parent()
                .removeClass("active");
        } else {
            $(".sidebar-dropdown").removeClass("active");
            $(this)
                .next(".sidebar-submenu")
                .slideDown(200);
            $(this)
                .parent()
                .addClass("active");
        }
    });

    $("#close-sidebar").click(function () {
        $(".page-wrapper").removeClass("toggled");
    });
    $("#show-sidebar").click(function () {
        $(".page-wrapper").addClass("toggled");
    });
});




function Vote_Good(Id, Password, BoardID) {

    var url = "/iBoard/Vote_Good?Id=" + Id + "&Password=" + Password + "&BoardID=" + BoardID;

    $.ajax({
        method: "GET",
        url: url,
        contentType: "application/x-www-form-urlencoded; charset=UTF-8",
        cache: false
    }).done(function (html) {
        if (html != -1)
            $(".recommend").html(html);
        else {
            $("#vote_message").removeAttr("style");
        }
    });

}

function Vote_NoGood(Id, Password, BoardID) {

    var url = "/iBoard/Vote_NoGood?Id=" + Id + "&Password=" + Password + "&BoardID=" + BoardID;

    $.ajax({
        method: "GET",
        url: url,
        contentType: "application/x-www-form-urlencoded; charset=UTF-8",
        cache: false
    }).done(function (html) {
        if (html != -1)
            $(".norecommend").html(html);
        else {
            $("#vote_message").removeAttr("style");
        }
    });

}


function OnCopyShotCut(shotcut, message) {

    var tempElem = document.createElement('textarea');
    tempElem.value = shotcut;
    document.body.appendChild(tempElem);

    tempElem.select();
    document.execCommand("copy");
    document.body.removeChild(tempElem);

    if (message == null) {
        message = 'It has been copied.';
    }

    alert(message);
}

function ajaxCommend(url, name) {

    $.ajax({
        method: "GET",
        url: url,
        contentType: "html",
        cache: false
    }).done(function (html) {
        $(name).html(html);
    });
}


function closeWin(bName, days) {

    if ($('#isChecked').prop('checked')) {
        setCookie(bName, "done", days);
    }

    $("#" + bName).css({ "visibility": "hidden" });
}

function setCookie(name, value, expiredays) {
    var todayDate = new Date();
    todayDate.setDate(todayDate.getDate() + expiredays);
    document.cookie = name + "=" + escape(value) + "; path=/; expires=" + todayDate.toGMTString() + ";";
}

function showBanner(bName) {
    cookiedata = document.cookie;
    if (cookiedata.indexOf(bName + "=done") < 0) {
        document.all[bName].style.visibility = "visible";
    }
    else {
        document.all[bName].style.visibility = "hidden";
    }
}
