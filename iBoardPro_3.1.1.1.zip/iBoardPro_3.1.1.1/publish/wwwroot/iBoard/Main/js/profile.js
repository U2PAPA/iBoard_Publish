﻿$(document).ready(function () {
    // check passwrod
    var password = document.getElementById("password")
        , confirm_password = document.getElementById("confirm_password");

    function validatePassword() {
        if (password.value != confirm_password.value) {
            confirm_password.setCustomValidity("Passwords Don't Match");
        } else {
            confirm_password.setCustomValidity('');
        }
    }

    password.onchange = validatePassword;
    confirm_password.onkeyup = validatePassword;
});


$("#UserImage").on("change", function () {

    var files = $(this).prop('files');
    checkFile(files, 'image');
});

$("#IconImage").on("change", function () {

    var files = $(this).prop('files');
    checkFile(files, 'icon');
});


function checkFile(files, type) {

    if (files.length > 0) {

        for (var i = 0; i <= files.length - 1; i++) {
            var fileName, fileExtension;

            fileName = files.item(i).name;
            fileExtension = fileName.replace(/^.*\./, '');
            
            if (fileExtension == 'png' || fileExtension == 'jpg' || fileExtension == 'jpeg' || fileExtension == 'gif') {
                readImageFile(files.item(i), type);
            }
            else {

                if (type == 'icon') {
                    $("#IconImage").val("");
                }
                else {
                    $("#UserImage").val("");
                }

                alert("허용하는 확장자는 png, jpg, jped, gif 입니다.");
            }
        }
    }
}

function readImageFile(file, type) {

    var reader = new FileReader();

    reader.onload = function (e) {
        var img = new Image();
        img.src = e.target.result;

        img.onload = function () {
            var w = this.width;
            var h = this.height;

            if (type == 'icon') {
                if (w <= 50 && h <= 50) {
                    $('#img_IconImage').attr('src', e.target.result);
                }
                else {
                    $("#IconImage").val("");
                    alert("이미지 크기는 가로(50픽셀)x세로(50픽셀) 이하로 해주세요.");
                }
            }
            else if (type == 'image') {
                if (w <= 100 && h <= 100) {
                    $('#img_UserImage').attr('src', e.target.result);
                }
                else {
                    $("#UserImage").val("");
                    alert("이미지 크기는 가로(100픽셀)x세로(100픽셀) 이하로 해주세요.");
                }
            }
        }
    };
    reader.readAsDataURL(file);
}