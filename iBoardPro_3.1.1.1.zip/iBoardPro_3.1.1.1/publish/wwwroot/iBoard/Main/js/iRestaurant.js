﻿

function SaveMenu() {

    var Id = $("#Id").val();
    var BoardId = $("#BoardId").val();
    var Category = $("#Category").val();
    var CategoryEnglish = $("#CategoryEnglish").val();
    var Menu = $("#Menu").val();
    var MenuEnglish = $("#MenuEnglish").val();
    var Price = $("#Price").val();
   
    if (Category != "" && Menu != "" && Price != "") {
        var query = "/iRestaurant/SaveMenu?Id=" + Id + "&BoardId=" + BoardId + "&Category=" + encodeURIComponent(Category) + "&CategoryEnglish=" + encodeURIComponent(CategoryEnglish) + "&Menu=" + encodeURIComponent(Menu) + "&MenuEnglish=" + encodeURIComponent(MenuEnglish) + "&Price=" + Price;

        $.ajax({
            method: "GET",
            url: query,
            contentType: "application/x-www-form-urlencoded; charset=UTF-8",
            cache: false
        }).done(function (html) {
            alert("정상적으로 처리 되었습니다.");
            ShowMenu(BoardId);
        });

        Category = $("#Category").val("");
        CategoryEnglish = $("#CategoryEnglish").val("");
        Menu = $("#Menu").val("");
        MenuEnglish = $("#MenuEnglish").val("");
        Price = $("#Price").val("");
    }
    else {
        alert("카테고리, 메뉴, 가격은 필수 입력 입니다.");
    }
}

function ShowMenu(BoardId) {
   
    var query = "/iRestaurant/ShowMenu?Id=" + BoardId;

    $.ajax({
        method: "GET",
        url: query,
        contentType: "application/x-www-form-urlencoded; charset=UTF-8",
        cache: false
    }).done(function (html) {
        $("#AddTableMain").html(html);
        $("#AddTableMainPOP").html(html);
    });
}

function changeQty(qty) {
    var quantity = $("#quantity").val()

    quantity = parseInt(quantity) + parseInt(qty);
    if (quantity <= 0) quantity = 1;

    $("#quantity").val(quantity)
}


function DeleteMenu(Id) {

    var query = "/iRestaurant/DeleteMenu?Id=" + Id;
    var BoardId = $("#BoardId").val();

    if (confirm("선택된 메뉴를 삭제 하시겠습니까 ?")) {
        $.ajax({
            method: "GET",
            url: query,
            contentType: "application/x-www-form-urlencoded; charset=UTF-8",
            cache: false
        }).done(function (html) {
            ShowMenu(BoardId)
        });
    }
}

function UpdateMenu(Id, Category, CategoryEnglish, Menu, MenuEnglish, Price) {
    $("#Id").val(Id);
    $("#Category").val(Category);
    $("#CategoryEnglish").val(CategoryEnglish);
    $("#Menu").val(Menu);
    $("#MenuEnglish").val(MenuEnglish);
    $("#Price").val(Price);
}


function InitMenu(Category, CategoryEnglish) {
    $("#Category").val(Category);
    $("#CategoryEnglish").val(CategoryEnglish);
}
